ProcName=lnccs
MYPID=`pidof $ProcName`
kill -9 $MYPID
